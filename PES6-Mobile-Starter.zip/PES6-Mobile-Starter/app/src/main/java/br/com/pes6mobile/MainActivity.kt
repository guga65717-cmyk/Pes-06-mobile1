package br.com.pes6mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val pickDisc = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }
        val title = TextView(this).apply {
            text = "PES6 MOBILE"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Selecione uma imagem de disco PS2 (.ISO ou .CSO)"
            textSize = 16f
            setTextColor(0xFFB8C7D9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        val choose = Button(this).apply {
            text = "ESCOLHER ISO / CSO"
            setOnClickListener { openDiscPicker() }
        }
        val padPreview = SoccerPadView(this)
        page.addView(title, LinearLayout.LayoutParams(-1, -2))
        page.addView(status, LinearLayout.LayoutParams(-1, -2))
        page.addView(choose, LinearLayout.LayoutParams(-2, -2))
        page.addView(padPreview, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun openDiscPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream",
                "application/x-cd-image"
            ))
        }
        startActivityForResult(intent, pickDisc)
    }

    @Deprecated("Kept compatible with the starter template")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickDisc && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                status.text = "Arquivo selecionado: ${uri.lastPathSegment}\n" +
                    "Próxima etapa: conectar o núcleo Play! para iniciar o jogo."
                Toast.makeText(this, "Imagem selecionada", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

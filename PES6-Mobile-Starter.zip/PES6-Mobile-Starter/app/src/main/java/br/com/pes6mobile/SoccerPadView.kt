package br.com.pes6mobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Protótipo visual de controles de futebol.
 * TODO: mapear cada evento para a API de input do núcleo Play!.
 */
class SoccerPadView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val active = mutableSetOf<String>()

    private val buttons = listOf(
        "□" to "CHUTE", "△" to "ENFIADA",
        "○" to "CARRINHO", "×" to "PASSE",
        "L1" to "TÁTICA", "R1" to "CORRIDA",
        "L2" to "PROTEGER", "R2" to "SPRINT"
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = 0xFF243447.toInt()
        p.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(8f, 8f, w - 8f, h - 8f), 22f, 22f, p)

        // D-pad esquerdo
        drawCircleButton(canvas, w * .13f, h * .53f, h * .19f, "✚", "D-PAD")
        // Analógico esquerdo
        p.color = 0x665B718A
        canvas.drawCircle(w * .31f, h * .57f, h * .13f, p)
        p.color = 0xFFB8C7D9.toInt()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        canvas.drawCircle(w * .31f, h * .57f, h * .13f, p)
        p.style = Paint.Style.FILL
        drawText(canvas, "ANALÓGICO", w * .31f, h * .79f, 22f)

        // Botões de ação à direita
        val centers = listOf(
            Triple("△", w * .82f, h * .28f),
            Triple("□", w * .75f, h * .48f),
            Triple("○", w * .89f, h * .48f),
            Triple("×", w * .82f, h * .68f)
        )
        centers.forEach { (label, x, y) -> drawCircleButton(canvas, x, y, h * .105f, label, label) }

        drawText(canvas, "L1", w * .43f, h * .20f, 28f)
        drawText(canvas, "L2", w * .53f, h * .20f, 28f)
        drawText(canvas, "R1", w * .68f, h * .20f, 28f)
        drawText(canvas, "R2", w * .94f, h * .20f, 28f)
        drawText(canvas, "PASSE", w * .82f, h * .90f, 20f)
    }

    private fun drawCircleButton(c: Canvas, x: Float, y: Float, r: Float, label: String, id: String) {
        p.style = Paint.Style.FILL
        p.color = if (active.contains(id)) 0xFF20A66A.toInt() else 0xFF52677D.toInt()
        c.drawCircle(x, y, r, p)
        p.color = 0xFFFFFFFF.toInt()
        p.textAlign = Paint.Align.CENTER
        p.textSize = r * .85f
        c.drawText(label, x, y + p.textSize * .34f, p)
    }

    private fun drawText(c: Canvas, text: String, x: Float, y: Float, size: Float) {
        p.color = 0xFFEAF2F8.toInt()
        p.textAlign = Paint.Align.CENTER
        p.textSize = size
        c.drawText(text, x, y, p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val id = when {
            event.x > width * .70f && event.y < height * .40f -> "△"
            event.x > width * .70f && event.y < height * .58f -> "□"
            event.x > width * .70f && event.y < height * .78f -> "×"
            event.x > width * .70f -> "○"
            event.x < width * .22f -> "D-PAD"
            else -> "ANALÓGICO"
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> active.add(id)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> active.clear()
        }
        invalidate()
        return true
    }
}
